﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace ClickMe
{
    public partial class Form1 : Form
    {
        // creating new random number generator
        Random rand = new Random();

        // create timer for time based actions
        System.Windows.Forms.Timer Clock = new System.Windows.Forms.Timer();

        // create variable to store elapsed time since last interaction
        int _lastInteraction = 0;

        public Form1()
        {
            // initializing Form
            InitializeComponent();
        }

        // when mouse enters form, move to random location on primary screen
        private void Form1_MouseEnter(object sender, EventArgs e)
        {
            moveRandom();
            _lastInteraction = 0;
        }

        private void Form1_MouseHover(object sender, EventArgs e)
        {
            moveRandom();
            _lastInteraction = 0;
        }

        // when button is clicked (only possible by pressing Enter) close the form
        private void button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void moveRandom() {
            // generate random location on x and y axis
            int x = this.rand.Next(0, Screen.PrimaryScreen.Bounds.Width - this.Width);
            int y = this.rand.Next(0, Screen.PrimaryScreen.Bounds.Height - this.Height);

            // check for x mouse overlap
            while (Cursor.Position.X > x && Cursor.Position.X < x + this.Width) {
                // fix y mouse overlap by generating new random locations on x axis
                x = this.rand.Next(0, Screen.PrimaryScreen.Bounds.Width - this.Width);
            }

            // check for y mouse overlap
            while (Cursor.Position.Y > y && Cursor.Position.X < y + this.Height)
            {
                // fix y mouse overlap by generating new random locations on y axis
                y = this.rand.Next(0, Screen.PrimaryScreen.Bounds.Height - this.Height);
            }

            // move form
            Location = new Point(x, y);

            this.Focus();
            button.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Clock.Interval = 500; // timer intervall (1sec)
            Clock.Start();
            Clock.Tick += new EventHandler(Clock_Tick);

        }

        // will be executed two times every second
        public void Clock_Tick(object sender, EventArgs eArgs)
        {
            if (sender == Clock)
            {
                // random movement after 8seconds manager
                _lastInteraction = _lastInteraction + 500;
                if (_lastInteraction > 8000) {
                    moveRandom();
                }
            }
        }
    }
}
